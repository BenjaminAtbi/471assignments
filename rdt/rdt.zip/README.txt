Everything works to specifications as far as I can tell.

You can run from commandline by the proscribed method (ex. rdt.TestServer 2222 3333)

Some Classes from the RDT.java file were moved to their own file

I did not implement any bonus specifications